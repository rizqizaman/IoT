Arduino Web Based Online Temperature Monitoring
Di download dari: http://www.bagasdika.web.id/?p=104

Silahkan mengubah dengan bebas source code yang ada. 
Mohon tetap cantumkan sumber asli baik yang saya dapatkan dari hal.
web tertentu maupun yang sudah saya ubah. Terima Kasih

Salam Pemuda!
Jogja, 28 Okt 2015.